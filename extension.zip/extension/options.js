// Settings are stored in chrome.storage.local (this device only). Server addresses must be https,
// except a local dev server on localhost.
const DEFAULTS = { backend: "", apiKey: "", topN: 5 };
const form = document.getElementById("settings");
const backend = document.getElementById("backend");
const apiKey = document.getElementById("apiKey");
const topN = document.getElementById("topN");
const status = document.getElementById("status");

chrome.storage.local.get(DEFAULTS).then((s) => {
  backend.value = s.backend;
  apiKey.value = s.apiKey;
  topN.value = s.topN;
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const origin = Sift.serverOrigin(backend.value.trim());
  if (!origin) {
    status.textContent = "Enter a full https:// address. Plain http is only allowed for localhost.";
    return;
  }
  const key = apiKey.value.trim();
  if (!key.startsWith("sift_")) {
    status.textContent = "Sift keys start with sift_. Check that you pasted the whole key.";
    return;
  }
  const granted = await chrome.permissions.request({ origins: [`${origin}/*`] });
  if (!granted) {
    status.textContent = "Sift needs permission to reach that server. Settings weren't saved.";
    return;
  }
  await chrome.storage.local.set({
    backend: origin,
    apiKey: key,
    topN: Math.max(0, Math.min(20, Number(topN.value) || 0)),
  });

  status.textContent = "Checking the key…";
  let r = null;
  try {
    r = await fetch(`${origin}/api/lookup`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Sift-Key": key },
      body: JSON.stringify({ videos: [] }),
      signal: AbortSignal.timeout(30000),
    });
  } catch { /* reported below */ }
  if (!r) status.textContent = "Settings saved, but the server couldn't be reached. Check the address.";
  else if (r.status === 401) status.textContent = "Settings saved, but the server didn't accept that key.";
  else if (r.ok) status.textContent = "Settings saved. The server accepted your key.";
  else status.textContent = `Settings saved, but the server returned ${r.status}.`;
});
