// Talks to the Sift backend on behalf of the content scripts. The API key never leaves this
// worker except in requests to the configured server.
importScripts("lib.js");

// Settings live in chrome.storage.local, not sync: the permission to reach the server is granted
// per device, and the key shouldn't be copied to every browser signed into the same account.
const DEFAULTS = { backend: "", apiKey: "", topN: 5 };
const TIMEOUT_MS = globalThis.SIFT_TIMEOUT_MS || 30000;

async function call({ type, payload }) {
  const { backend, apiKey } = await chrome.storage.local.get(DEFAULTS);
  if (!backend || !apiKey) return { ok: false, reason: "no_key" };
  const origin = Sift.serverOrigin(backend);
  if (!origin) return { ok: false, reason: "insecure_server" };
  if (!(await chrome.permissions.contains({ origins: [`${origin}/*`] }))) return { ok: false, reason: "no_permission" };

  const headers = { "X-Sift-Key": apiKey };
  let url, init;
  if (type === "lookup" || type === "check") {
    url = `${origin}/api/${type}`;
    init = { method: "POST", headers: { ...headers, "Content-Type": "application/json" }, body: JSON.stringify(payload) };
  } else if (type === "verdict") {
    const q = new URLSearchParams(Object.entries(payload).filter(([, v]) => v != null));
    url = `${origin}/api/verdict?${q}`;
    init = { headers };
  } else {
    return { ok: false, reason: "backend_error" };
  }

  let r;
  try {
    r = await fetch(url, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) });
  } catch (e) {
    return { ok: false, reason: e?.name === "TimeoutError" ? "timeout" : "backend_error" };
  }
  if (r.status === 401) return { ok: false, reason: "unauthorized" };
  // 403 comes from Front Door's WAF (rate limit or blocked request) or the app's access rules; 429 from limits.
  if (r.status === 403 || r.status === 429) return { ok: false, reason: "throttled" };
  if (!r.ok) return { ok: false, reason: "backend_error" };
  try {
    return { ok: true, status: r.status, data: await r.json() };
  } catch {
    return { ok: false, reason: "backend_error" };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  call(msg).then(sendResponse, () => sendResponse({ ok: false, reason: "backend_error" }));
  return true; // respond asynchronously
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

// Earlier versions kept settings in chrome.storage.sync. Move them to local once.
async function migrateFromSync() {
  const local = await chrome.storage.local.get(DEFAULTS);
  if (local.backend || local.apiKey) return;
  const old = await chrome.storage.sync.get(DEFAULTS);
  if (old.backend || old.apiKey) {
    await chrome.storage.local.set(old);
    await chrome.storage.sync.remove(Object.keys(DEFAULTS));
  }
}

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  await migrateFromSync();
  if (reason !== "install") return;
  const { backend, apiKey } = await chrome.storage.local.get(DEFAULTS);
  if (!backend || !apiKey) chrome.runtime.openOptionsPage();
});
