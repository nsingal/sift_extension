// Runs in YouTube's own page context for one job: reading the innertube API key,
// which the extension's isolated content scripts can't see. It exposes nothing else.
(() => {
  let tries = 0;
  const timer = setInterval(() => {
    const key = window.ytcfg?.get?.("INNERTUBE_API_KEY");
    if (key) {
      document.documentElement.dataset.siftInnertubeKey = key;
      clearInterval(timer);
    } else if (++tries > 120) {
      clearInterval(timer);
    }
  }, 250);
})();
