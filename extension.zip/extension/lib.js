// Pure helpers, shared by the content scripts (and loadable in Node for tests).
(() => {
  const Sift = (globalThis.Sift = globalThis.Sift || {});

  Sift.LANGS = ["en", "en-US", "en-GB"];
  const YT = "https://www.youtube.com";
  const NAMED = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };

  Sift.decodeEntities = (s) =>
    s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (m, e) => {
      const l = e.toLowerCase();
      if (l[0] !== "#") return NAMED[l];
      const cp = l[1] === "x" ? parseInt(l.slice(2), 16) : parseInt(l.slice(1), 10);
      try { return String.fromCodePoint(cp); } catch { return m; }
    });

  // YouTube caption XML: <transcript><text start=".." dur="..">line</text>...</transcript>.
  // Text is often entity-encoded twice and can contain <font> tags. Parsed with regexes
  // because YouTube's Trusted Types policy blocks the DOM HTML parsers.
  Sift.parseCaptionXml = (xml) => {
    const lines = [];
    const re = /<(text|p)\b[^>]*>([\s\S]*?)<\/\1>/g;
    let m;
    while ((m = re.exec(xml))) {
      const s = Sift.decodeEntities(Sift.decodeEntities(m[2]).replace(/<[^>]+>/g, " ")).trim();
      if (s) lines.push(s);
    }
    return lines;
  };

  // Deterministic choice, so every user hashes the same track for a video:
  // manual English beats auto-generated English; exact language codes beat regional variants.
  Sift.pickTrack = (tracks) => {
    const find = (ok) => {
      for (const lang of Sift.LANGS) {
        const t = tracks.find((t) => t.languageCode === lang && ok(t));
        if (t) return t;
      }
      return tracks.find((t) => /^en\b/.test(t.languageCode || "") && ok(t));
    };
    return find((t) => t.kind !== "asr") || find((t) => t.kind === "asr") || null;
  };

  Sift.videoIdFromHref = (href) => {
    try {
      const u = new URL(href, YT);
      const id = u.pathname === "/watch" ? u.searchParams.get("v") : null;
      return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
    } catch { return null; }
  };

  // "/@name/videos" -> "/@name", "/channel/UCxyz/about" -> "/channel/UCxyz"
  Sift.channelKeyFromHref = (href) => {
    try {
      const parts = new URL(href, YT).pathname.split("/").filter(Boolean);
      if (!parts.length) return null;
      if (parts[0].startsWith("@")) return "/" + decodeURIComponent(parts[0]).toLowerCase();
      if (["channel", "c", "user"].includes(parts[0]) && parts[1]) return `/${parts[0]}/${parts[1]}`;
      return null;
    } catch { return null; }
  };

  Sift.pct = (x) => `${Math.round((x ?? 0) * 100)}%`;

  // Server addresses must be https, except a local dev server. The API key travels in a header,
  // so plain http anywhere else would expose it. Returns the origin, or null if not allowed.
  Sift.serverOrigin = (value) => {
    let u;
    try { u = new URL(value); } catch { return null; }
    const local = u.hostname === "localhost" || u.hostname === "127.0.0.1";
    return u.protocol === "https:" || (u.protocol === "http:" && local) ? u.origin : null;
  };

  // The watch page updates its channel name asynchronously after navigation, so at "play" time it
  // can still show the previous video's channel. Only trust the page's channel when it matches the
  // channel name YouTube returned for this exact video; otherwise send none.
  const norm = (s) => (s || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
  Sift.verifiedChannel = (channel, author) =>
    channel?.channel_key && author && norm(channel.channel_title) === norm(author)
      ? channel
      : { channel_key: null, channel_title: null };

  const REASONS = {
    no_captions: "No English captions",
    unplayable: "Video can't be checked",
    too_short: "Too little speech to judge",
    rate_limited: "Hourly check limit reached",
    budget_exhausted: "This month's AI-check budget is used up. Already-checked videos still work",
    detector_error: "The AI check failed this time",
    backend_error: "Can't reach the Sift server",
    timeout: "The Sift server took too long to respond",
    throttled: "The Sift server is limiting requests. Try again in a minute",
    no_key: "Add your Sift server and key in the extension settings",
    unauthorized: "The Sift server didn't accept your key",
    no_permission: "Sift needs permission to reach your server. Open the extension settings and save",
    insecure_server: "Your Sift server address must use https",
    pot_required: "YouTube wouldn't share this video's captions",
    blocked: "YouTube blocked the caption request",
    bad_captions: "YouTube returned an unexpected caption address",
    client_outdated: "YouTube rejected Sift's caption request. Sift needs an update",
    empty_captions: "Captions came back empty",
    not_ready: "The YouTube page wasn't ready",
  };
  // Outcomes that won't change by playing the video, so the search note doesn't promise a retry.
  const NO_RETRY_HINT = new Set(["no_captions", "unplayable", "too_short", "rate_limited", "budget_exhausted",
    "no_key", "unauthorized", "no_permission", "insecure_server", "client_outdated"]);

  // context: "search" or "watch"
  Sift.describe = (v, context) => {
    if (!v) return context === "search" ? "Not checked yet. Checks when you play it." : "";
    switch (v.state) {
      case "checking":
        return "Checking the transcript…";
      case "stale":
        return "Still checking. The result will be ready next time you see this video.";
      case "kept":
        return v.score < 0.2
          ? `Script reads as human-written. AI score ${Sift.pct(v.score)}.`
          : `Script has some AI-assisted passages. AI score ${Sift.pct(v.score)}.`;
      case "hidden":
        return v.reason === "channel"
          ? `Hidden because ${v.channel_flagged} of ${v.channel_checked} checked videos from this channel read as AI-written.`
          : `Script reads as AI-written. AI score ${Sift.pct(v.score)}.`;
      default: {
        const base = `${REASONS[v.reason] || "Couldn't check this video"}.`;
        return context === "search" && !NO_RETRY_HINT.has(v.reason) ? `${base} Checks again when you play it.` : base;
      }
    }
  };
})();
