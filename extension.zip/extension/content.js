// Search pages: look up cached verdicts for every result, check the top N uncached
// results right away, and leave the rest for when they're played.
// Watch pages: every time a video starts playing, fetch its transcript and send it to the
// backend, which reuses the cached analysis if the transcript hash matches.
(() => {
  const S = globalThis.Sift;
  const TOP_WINDOW = 20;             // "top of the search": only these positions spend the budget
  const TRANSCRIPT_CONCURRENCY = 3;
  const LOOKUP_BATCH = 100;          // the backend's per-request limit
  const RESULT_SELECTOR = "ytd-search ytd-video-renderer, ytd-search yt-lockup-view-model";
  // A 202 means the server is analyzing the transcript; poll until it's done (about 90s max).
  const POLL_DELAYS = S.POLL_DELAYS || [1, 1, 2, 2, 3, 3, 5, 5, 8, 8, 10, 10, 10, 10, 10];
  const DEBOUNCE_MS = S.DEBOUNCE_MS ?? 300;
  // How long this tab remembers an answer. YouTube tabs live for hours, so anything that can
  // change (errors, "nothing cached yet", channel-based guesses) expires; real verdicts don't.
  const RETRY_AFTER_MS = 60_000;
  const RECHECK_AFTER_MS = 5 * 60_000;

  let settings = { topN: 5 };
  chrome.storage.local.get({ topN: 5 }).then((v) => (settings = v));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.topN) settings.topN = changes.topN.newValue;
    if (changes.backend || changes.apiKey) {
      verdicts.clear();   // e.g. "add your key" no longer applies
      schedule();
    }
  });

  // ---- what this tab knows ----
  // videoId -> { v, expires }. v is a verdict, or null meaning "looked up, nothing cached".
  const verdicts = new Map();
  const inflight = new Map();

  function remember(vid, v) {
    let ttl = RETRY_AFTER_MS;
    if (v === null || v.reason === "channel") ttl = RECHECK_AFTER_MS;
    else if (v.state === "kept" || v.state === "hidden") ttl = Infinity;
    verdicts.set(vid, { v, expires: Date.now() + ttl });
  }
  // undefined = unknown (look it up), null = nothing cached, otherwise the verdict
  function recall(vid) {
    const e = verdicts.get(vid);
    if (!e) return undefined;
    if (e.expires <= Date.now()) {
      verdicts.delete(vid);
      return undefined;
    }
    return e.v;
  }
  const currentVerdict = (vid) => (inflight.has(vid) ? { state: "checking" } : recall(vid));

  // ---- backend calls ----
  class ApiError extends Error {
    constructor(reason) { super(reason); this.reason = reason; }
  }
  // Returns { http, body }. The HTTP status and the JSON body stay separate because response
  // bodies have their own "status" field (e.g. {"status": "pending"} on a 202).
  const api = (type, payload) =>
    chrome.runtime.sendMessage({ type, payload }).then(
      (r) => {
        if (!r?.ok) throw new ApiError(r?.reason || "backend_error");
        return { http: r.status, body: r.data };
      },
      () => { throw new ApiError("backend_error"); },   // the worker went away mid-request
    );

  const asVerdict = (body) =>
    body?.verdict?.state ? { ...body.verdict, reanalyzed: !!body.reanalyzed } : { state: "unchecked", reason: "backend_error" };

  const sleep = (s) => new Promise((r) => setTimeout(r, s * 1000));
  async function waitForVerdict(videoId, hash, channel) {
    for (const d of POLL_DELAYS) {
      await sleep(d);
      const r = await api("verdict", { video_id: videoId, hash, ...channel });
      if (r.http !== 202) return r.body;
    }
    return { verdict: { state: "stale" } };
  }

  // ---- concurrency-limited checks ----
  const queue = [];
  let active = 0;
  const pump = () => {
    while (active < TRANSCRIPT_CONCURRENCY && queue.length) {
      const { fn, resolve } = queue.shift();
      active++;
      fn().then(resolve).finally(() => { active--; pump(); });
    }
  };
  const limited = (fn) => new Promise((resolve) => { queue.push({ fn, resolve }); pump(); });

  function checkVideo(videoId, pageChannel) {
    if (inflight.has(videoId)) return inflight.get(videoId);
    const p = limited(async () => {
      try {
        let t;
        try {
          t = await S.fetchTranscript(videoId);
        } catch (e) {
          if (e instanceof S.TranscriptError && e.report) {
            return asVerdict((await api("check", { video_id: videoId, failure: e.reason })).body);
          }
          return { state: "unchecked", reason: e.reason || "blocked" };
        }
        const channel = S.verifiedChannel(pageChannel, t.author);
        const r = await api("check", { video_id: videoId, ...channel, text: t.text, track: t.track });
        return asVerdict(r.http === 202 ? await waitForVerdict(videoId, r.body.hash, channel) : r.body);
      } catch (e) {
        return { state: "unchecked", reason: e.reason || "backend_error" };
      }
    }).then((v) => {
      remember(videoId, v);
      inflight.delete(videoId);
      return v;
    });
    inflight.set(videoId, p);
    return p;
  }

  async function lookupAll(infos) {
    const batches = [];
    for (let i = 0; i < infos.length; i += LOOKUP_BATCH) batches.push(infos.slice(i, i + LOOKUP_BATCH));
    await Promise.all(batches.map(async (batch) => {
      try {
        const { body } = await api("lookup", { videos: batch.map((i) => ({ video_id: i.vid, ...i.channel })) });
        const got = body?.verdicts || {};
        for (const i of batch) remember(i.vid, got[i.vid] || null);
      } catch (e) {
        for (const i of batch) remember(i.vid, { state: "unchecked", reason: e.reason || "backend_error" });
      }
    }));
  }

  // ---- search results ----
  function resultInfo(r) {
    const link = r.querySelector('a#video-title[href], a#thumbnail[href], a[href^="/watch?v="]');
    const vid = link && S.videoIdFromHref(link.getAttribute("href"));
    if (!vid) return null;
    const ch = r.querySelector('ytd-channel-name a[href], a[href^="/@"], a[href^="/channel/"]');
    const title = (r.querySelector("#video-title, h3") || link).textContent.trim();
    return {
      vid,
      title,
      channel: {
        channel_key: ch ? S.channelKeyFromHref(ch.getAttribute("href")) : null,
        channel_title: ch ? ch.textContent.trim().slice(0, 200) : null,
      },
    };
  }

  const annotations = new WeakMap();

  // YouTube recycles result elements between searches, so annotations are tied to a video id.
  function ensureAnnotation(r, info) {
    let a = annotations.get(r);
    if (a && a.vid === info.vid && a.note.isConnected && a.bar.isConnected) return a;
    if (a) { a.note.remove(); a.bar.remove(); }
    r.removeAttribute("sift-state");
    r.removeAttribute("sift-revealed");

    const why = Object.assign(document.createElement("span"), { className: "sift-why" });
    const title = Object.assign(document.createElement("span"), { className: "sift-title" });
    const text = Object.assign(document.createElement("span"), { className: "sift-bar-text" });
    text.append(why, " ", title);
    const btn = Object.assign(document.createElement("button"), { type: "button", className: "sift-reveal", textContent: "Show" });
    btn.setAttribute("aria-expanded", "false");
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const open = r.toggleAttribute("sift-revealed");
      btn.textContent = open ? "Hide" : "Show";
      btn.setAttribute("aria-expanded", String(open));
    });
    const bar = Object.assign(document.createElement("div"), { className: "sift-bar" });
    bar.append(text, btn);
    const note = Object.assign(document.createElement("div"), { className: "sift-note" });

    r.prepend(bar);
    (r.querySelector("#meta, .yt-lockup-metadata-view-model") || r).append(note);
    a = { vid: info.vid, note, bar, why, title, key: "" };
    annotations.set(r, a);
    return a;
  }

  function paint(r, info) {
    const v = currentVerdict(info.vid);
    const a = ensureAnnotation(r, info);
    const state = v ? v.state : "unqueued";
    const text = S.describe(v, "search");
    const key = `${state}|${text}`;
    if (a.key === key) return;
    a.key = key;
    r.setAttribute("sift-state", state);
    a.note.dataset.state = state;
    a.note.textContent = `Sift: ${text}`;
    if (state === "hidden") {
      a.why.textContent = v.reason === "channel"
        ? "Hidden by Sift: this channel mostly posts AI-written videos."
        : `Hidden by Sift: AI score ${S.pct(v.score)}.`;
      a.title.textContent = info.title;
    }
  }

  let navCount = 0;        // bumps on every YouTube navigation, including repeating a search
  let budgetNav = -1;
  let budget = 0;
  const spent = new Set();

  let scanning = false;
  let rescan = false;
  async function scanSearch() {
    if (scanning) { rescan = true; return; }
    scanning = true;
    try {
      await scanOnce();
    } finally {
      scanning = false;
      if (rescan) { rescan = false; schedule(); }
    }
  }

  async function scanOnce() {
    if (budgetNav !== navCount) {   // a new search page: a fresh budget
      budgetNav = navCount;
      budget = settings.topN;
      spent.clear();
    }

    const items = [...document.querySelectorAll(RESULT_SELECTOR)]
      .map((r) => ({ r, info: resultInfo(r) }))
      .filter((x) => x.info);

    const unknown = [...new Map(
      items.filter((x) => recall(x.info.vid) === undefined && !inflight.has(x.info.vid)).map((x) => [x.info.vid, x.info])
    ).values()];
    if (unknown.length) await lookupAll(unknown);

    // Spend the budget on the highest-ranked results with nothing cached.
    items.slice(0, TOP_WINDOW).forEach((x) => {
      const vid = x.info.vid;
      if (budget <= 0 || spent.has(vid) || inflight.has(vid) || recall(vid) !== null) return;
      budget--;
      spent.add(vid);
      checkVideo(vid, x.info.channel).then(schedule);
    });

    for (const x of items) paint(x.r, x.info);
  }

  // ---- watch page ----
  const lookingUp = new Set();
  const playChecked = new Set();
  const watchVideoId = () => (location.pathname === "/watch" ? new URLSearchParams(location.search).get("v") : null);

  function watchChannel() {
    const a = document.querySelector("ytd-watch-metadata ytd-channel-name a[href], #owner ytd-channel-name a[href]");
    return {
      channel_key: a ? S.channelKeyFromHref(a.getAttribute("href")) : null,
      channel_title: a ? a.textContent.trim().slice(0, 200) : null,
    };
  }

  function renderBadge() {
    const vid = watchVideoId();
    let badge = document.getElementById("sift-badge");
    const v = vid && currentVerdict(vid);
    const text = v ? S.describe(v, "watch") : "";
    if (!text) { badge?.remove(); return; }

    const anchor = document.querySelector("ytd-watch-metadata #title");
    if (!anchor) return; // page still rendering; the observer will call again
    if (!badge) {
      badge = Object.assign(document.createElement("div"), { id: "sift-badge" });
      badge.setAttribute("role", "status");
    }
    if (badge.previousElementSibling !== anchor) anchor.after(badge);
    const extra = v.reanalyzed ? " The transcript changed since the last check, so it was checked again." : "";
    const full = `Sift: ${text}${extra}`;
    if (badge.textContent !== full) badge.textContent = full;
    badge.dataset.state = v.state;
  }

  async function onWatch() {
    const vid = watchVideoId();
    if (vid && recall(vid) === undefined && !inflight.has(vid) && !lookingUp.has(vid)) {
      lookingUp.add(vid);
      // No channel here: the page may still show the previous video's channel.
      await lookupAll([{ vid, channel: {} }]);
      lookingUp.delete(vid);
    }
    renderBadge();
  }

  // Check each video once per visit when it actually starts. Ads play in the same element, so
  // skip while one is showing; the real video's "playing" event arrives when the ad ends.
  function onPlay(e) {
    const vid = watchVideoId();
    if (!vid || !(e.target instanceof HTMLVideoElement) || !e.target.classList.contains("html5-main-video")) return;
    if (document.querySelector("#movie_player.ad-showing")) return;
    if (playChecked.has(vid)) return;
    playChecked.add(vid);
    checkVideo(vid, watchChannel()).then(renderBadge);
    renderBadge();
  }
  document.addEventListener("play", onPlay, true);
  document.addEventListener("playing", onPlay, true);

  document.addEventListener("yt-navigate-start", () => {
    // leaving a watch page: allow a fresh check the next time this video plays
    const vid = watchVideoId();
    if (vid) playChecked.delete(vid);
  });
  document.addEventListener("yt-navigate-finish", () => {
    navCount++;
    schedule();
  });

  // ---- routing ----
  let timer = null;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (location.pathname === "/results") scanSearch();
      else if (location.pathname === "/watch") onWatch();
    }, DEBOUNCE_MS);
  }

  const ours = (n) => n.nodeType === 1 && (n.id === "sift-badge" || n.classList.contains("sift-note") || n.classList.contains("sift-bar"));
  new MutationObserver((mutations) => {
    for (const m of mutations) {
      const t = m.target.nodeType === 1 ? m.target : m.target.parentElement;
      if (t?.closest?.(".sift-note, .sift-bar, #sift-badge")) continue;
      if ([...m.addedNodes, ...m.removedNodes].every(ours) && (m.addedNodes.length || m.removedNodes.length)) continue;
      schedule();
      return;
    }
  }).observe(document.documentElement, { childList: true, subtree: true });

  schedule();
})();
