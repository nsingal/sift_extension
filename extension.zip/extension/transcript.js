// Fetches a video's captions from the user's own browser, the same way
// youtube-transcript-api does: innertube player endpoint (Android client), then the
// caption track XML. Requests carry no cookies, so they aren't tied to the user's account.
// This uses an undocumented YouTube interface and is the part most likely to need updates.
(() => {
  const Sift = globalThis.Sift;

  // UPDATE WHEN YOUTUBE REJECTS IT. Mirrors INNERTUBE_CONTEXT in youtube-transcript-api
  // (youtube_transcript_api/_settings.py); when that library bumps its version, bump this.
  // A rejected version shows up as "YouTube rejected Sift's caption request".
  Sift.ANDROID_CLIENT_VERSION = "20.10.38";

  const CAPTION_HOST = "www.youtube.com";
  const CAPTION_PATH = "/api/timedtext";

  class TranscriptError extends Error {
    // report: true if the backend should cache this outcome (it won't change soon)
    constructor(reason, report) {
      super(reason);
      this.reason = reason;
      this.report = report;
    }
  }
  Sift.TranscriptError = TranscriptError;

  // Only ever fetch caption files from YouTube's caption endpoint, whatever the response says.
  function captionUrl(baseUrl) {
    let u;
    try { u = new URL(baseUrl, `https://${CAPTION_HOST}`); } catch { return null; }
    if (u.protocol !== "https:" || u.hostname !== CAPTION_HOST || u.pathname !== CAPTION_PATH) return null;
    u.searchParams.delete("fmt"); // plain XML, not srv3
    return u.toString();
  }

  Sift.fetchTranscript = async (videoId) => {
    const key = document.documentElement.dataset.siftInnertubeKey;
    if (!key) throw new TranscriptError("not_ready", false);

    const r = await fetch(`https://${CAPTION_HOST}/youtubei/v1/player?key=${encodeURIComponent(key)}&prettyPrint=false`, {
      method: "POST",
      credentials: "omit",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        context: { client: { clientName: "ANDROID", clientVersion: Sift.ANDROID_CLIENT_VERSION } },
        videoId,
      }),
    });
    if (r.status === 400) throw new TranscriptError("client_outdated", false);
    if (!r.ok) throw new TranscriptError("blocked", false);
    const data = await r.json();

    const status = data.playabilityStatus?.status;
    if (status && status !== "OK") {
      const reason = data.playabilityStatus.reason || "";
      if (status === "LOGIN_REQUIRED" && /bot/i.test(reason)) throw new TranscriptError("blocked", false);
      throw new TranscriptError("unplayable", true);
    }

    const tracks = data.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
    const track = Sift.pickTrack(tracks);
    if (!track) throw new TranscriptError("no_captions", true);
    if (String(track.baseUrl).includes("&exp=xpe")) throw new TranscriptError("pot_required", false);
    const url = captionUrl(track.baseUrl);
    if (!url) throw new TranscriptError("bad_captions", false);

    const cr = await fetch(url, { credentials: "omit" });
    if (!cr.ok) throw new TranscriptError("blocked", false);
    const lines = Sift.parseCaptionXml(await cr.text());
    if (!lines.length) throw new TranscriptError("empty_captions", false);

    return {
      text: lines.join("\n"),
      track: { kind: track.kind === "asr" ? "asr" : "manual", lang: String(track.languageCode).slice(0, 20) },
      // The channel name YouTube reports for this exact video; used to verify the page's channel.
      author: data.videoDetails?.author || null,
    };
  };
})();
